<!DOCTYPE html>

<html>

    <head>
        <meta charset="utf-8" />
        <title>Placement aléatoire</title>
    </head>

    <body>

        <?php include("connexion.php"); ?>

        <?php include("lecture.php"); ?>

        <?php include("placement.php"); ?>

    </body>

</html>
