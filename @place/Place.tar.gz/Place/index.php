<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Placement aléatoire</title>
</head>
<body>

    <?php include("connexion.php"); ?>

    <?php include("delete place.php"); ?>
    <?php include("insertion base.php"); ?>

    <?php include("lecture.php"); ?>
    <?php include("insertion base for.php"); ?>

    /*
    <?php include("lecture.php"); ?>
    <?php include("placement.php"); ?>
    */

</body>
</html>